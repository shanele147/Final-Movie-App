///* tái sử dụng các const key cho toàn bộ project bằng cách destructuring */
export const API_KEY = "f1b4eee850db3e17398de6ceb71ab9ab";
export const base_URL = "https://api.themoviedb.org/3/movie";